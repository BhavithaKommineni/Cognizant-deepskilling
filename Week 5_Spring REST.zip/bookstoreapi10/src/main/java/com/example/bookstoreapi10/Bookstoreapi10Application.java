package com.example.bookstoreapi10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bookstoreapi10Application {

	public static void main(String[] args) {
		SpringApplication.run(Bookstoreapi10Application.class, args);
	}

}
