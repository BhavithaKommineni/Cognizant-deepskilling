package com.example.bookstoreapi10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bookstoreapi10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
