package com.example.bookstoreapi8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bookstoreapi8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
