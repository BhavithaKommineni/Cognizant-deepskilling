package com.example.bookstoreapi12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bookstoreapi12Application {

	public static void main(String[] args) {
		SpringApplication.run(Bookstoreapi12Application.class, args);
	}

}
