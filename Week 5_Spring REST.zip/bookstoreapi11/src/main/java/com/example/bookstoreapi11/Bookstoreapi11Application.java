package com.example.bookstoreapi11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bookstoreapi11Application {

	public static void main(String[] args) {
		SpringApplication.run(Bookstoreapi11Application.class, args);
	}

}
