package com.example.bookstore_hateoas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreHateoasApplicationTests {

	@Test
	void contextLoads() {
	}

}
